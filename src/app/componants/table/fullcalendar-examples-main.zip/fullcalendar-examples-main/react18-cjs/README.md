
For testing https://github.com/fullcalendar/fullcalendar/issues/7170
