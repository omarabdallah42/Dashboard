import Layout from '../components/layout'

export default function AboutPage() {
  return (
    <Layout>
      About us
    </Layout>
  )
}
