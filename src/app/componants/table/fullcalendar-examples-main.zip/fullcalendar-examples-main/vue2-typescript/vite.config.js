import vue from '@vitejs/plugin-vue2'

export default {
  root: './',
  base: './',
  plugins: [vue()],
}
